-- =====================================================================
-- Multi-Vendor SaaS E-Commerce Platform
-- Module 5 Assignment (SQL: PostgreSQL syntax)
-- =====================================================================


-- =====================================================================
-- PART B: SQL DDL (Table Creation)
-- =====================================================================

-- Subscription plan table (created first because Vendor depends on it)
CREATE TABLE SubscriptionPlan (
    plan_id         SERIAL PRIMARY KEY,
    plan_name       VARCHAR(50)    NOT NULL UNIQUE,
    price           DECIMAL(10,2)  NOT NULL CHECK (price >= 0),
    duration_months INT            NOT NULL CHECK (duration_months > 0),
    features        TEXT
);

-- Q3: Vendor table with primary key and foreign key to SubscriptionPlan
-- (A vendor has exactly one plan at a time: SubscriptionPlan 1 --- N Vendor)
CREATE TABLE Vendor (
    vendor_id        SERIAL PRIMARY KEY,
    business_name    VARCHAR(150) NOT NULL,
    contact_person   VARCHAR(100) NOT NULL,
    email            VARCHAR(150) NOT NULL UNIQUE,
    phone            VARCHAR(20)  NOT NULL,
    business_address VARCHAR(255) NOT NULL,
    plan_id          INT          NOT NULL,
    CONSTRAINT fk_vendor_plan
        FOREIGN KEY (plan_id) REFERENCES SubscriptionPlan(plan_id)
        ON UPDATE CASCADE
        ON DELETE RESTRICT
);

-- Category table
CREATE TABLE Category (
    category_id   SERIAL PRIMARY KEY,
    category_name VARCHAR(100) NOT NULL UNIQUE,
    description   TEXT
);

-- Product table (each product belongs to exactly one vendor: Vendor 1 --- N Product)
CREATE TABLE Product (
    product_id     SERIAL PRIMARY KEY,
    vendor_id      INT           NOT NULL,
    product_name   VARCHAR(150)  NOT NULL,
    description    TEXT,
    price          DECIMAL(12,2) NOT NULL CHECK (price >= 0),
    stock_quantity INT           NOT NULL DEFAULT 0 CHECK (stock_quantity >= 0),
    status         VARCHAR(10)   NOT NULL DEFAULT 'active'
                   CHECK (status IN ('active', 'inactive')),
    CONSTRAINT fk_product_vendor
        FOREIGN KEY (vendor_id) REFERENCES Vendor(vendor_id)
        ON UPDATE CASCADE
        ON DELETE CASCADE
);

-- Q4: ProductCategory junction table to handle the M:N relationship
-- between Product and Category (composite primary key avoids duplicates)
CREATE TABLE ProductCategory (
    product_id  INT NOT NULL,
    category_id INT NOT NULL,
    PRIMARY KEY (product_id, category_id),
    CONSTRAINT fk_pc_product
        FOREIGN KEY (product_id) REFERENCES Product(product_id)
        ON UPDATE CASCADE
        ON DELETE CASCADE,
    CONSTRAINT fk_pc_category
        FOREIGN KEY (category_id) REFERENCES Category(category_id)
        ON UPDATE CASCADE
        ON DELETE CASCADE
);

-- Customer table
CREATE TABLE Customer (
    customer_id SERIAL PRIMARY KEY,
    name        VARCHAR(100) NOT NULL,
    email       VARCHAR(150) NOT NULL UNIQUE,
    phone       VARCHAR(20),
    address     VARCHAR(255)
);

-- Orders table (Customer 1 --- N Orders)
-- Named "Orders" because ORDER is a reserved SQL keyword
CREATE TABLE Orders (
    order_id     SERIAL PRIMARY KEY,
    customer_id  INT           NOT NULL,
    order_date   DATE          NOT NULL,
    total_amount DECIMAL(12,2) NOT NULL DEFAULT 0 CHECK (total_amount >= 0),
    order_status VARCHAR(20)   NOT NULL DEFAULT 'pending'
                 CHECK (order_status IN ('pending', 'processing', 'shipped', 'delivered', 'cancelled')),
    CONSTRAINT fk_orders_customer
        FOREIGN KEY (customer_id) REFERENCES Customer(customer_id)
        ON UPDATE CASCADE
        ON DELETE CASCADE
);

-- OrderItem table: one row per product in an order
-- (Orders 1 --- N OrderItem, Product 1 --- N OrderItem)
CREATE TABLE OrderItem (
    order_item_id SERIAL PRIMARY KEY,
    order_id      INT           NOT NULL,
    product_id    INT           NOT NULL,
    quantity      INT           NOT NULL CHECK (quantity > 0),
    unit_price    DECIMAL(12,2) NOT NULL CHECK (unit_price >= 0),
    subtotal      DECIMAL(12,2) NOT NULL CHECK (subtotal >= 0),
    CONSTRAINT fk_item_order
        FOREIGN KEY (order_id) REFERENCES Orders(order_id)
        ON UPDATE CASCADE
        ON DELETE CASCADE,
    CONSTRAINT fk_item_product
        FOREIGN KEY (product_id) REFERENCES Product(product_id)
        ON UPDATE CASCADE
        ON DELETE RESTRICT
);

-- Payment table (Orders 1 --- 1 Payment; UNIQUE on order_id enforces 1:1)
CREATE TABLE Payment (
    payment_id     SERIAL PRIMARY KEY,
    order_id       INT           NOT NULL UNIQUE,
    method         VARCHAR(20)   NOT NULL
                   CHECK (method IN ('Card', 'Bkash', 'PayPal', 'Cash on Delivery')),
    amount         DECIMAL(12,2) NOT NULL CHECK (amount >= 0),
    payment_date   DATE          NOT NULL,
    payment_status VARCHAR(20)   NOT NULL DEFAULT 'pending'
                   CHECK (payment_status IN ('pending', 'paid', 'failed', 'refunded')),
    CONSTRAINT fk_payment_order
        FOREIGN KEY (order_id) REFERENCES Orders(order_id)
        ON UPDATE CASCADE
        ON DELETE CASCADE
);


-- =====================================================================
-- SAMPLE DATA (needed so that the later queries have something to show)
-- =====================================================================

-- Subscription plans
INSERT INTO SubscriptionPlan (plan_name, price, duration_months, features) VALUES
('Basic',   1000.00,  1, 'Up to 50 products, email support'),
('Premium', 5000.00,  6, 'Up to 500 products, priority support, analytics'),
('Gold',    9000.00, 12, 'Unlimited products, 24/7 support, analytics, custom domain');

-- Categories
INSERT INTO Category (category_name, description) VALUES
('Electronics', 'Electronic devices and gadgets'),
('Fashion',     'Clothing, shoes and accessories'),
('Home',        'Home and kitchen products');

-- Another vendor (so that the vendor list has more than one row)
INSERT INTO Vendor (business_name, contact_person, email, phone, business_address, plan_id)
VALUES ('StyleHub', 'Nadia Islam', 'nadia@stylehub.com', '018XXXXXXXX', 'Chattogram, Bangladesh',
        (SELECT plan_id FROM SubscriptionPlan WHERE plan_name = 'Premium'));

-- Customers
INSERT INTO Customer (name, email, phone, address) VALUES
('Karim Uddin',  'karim@gmail.com',       '019XXXXXXXX', 'Dhaka, Bangladesh'),
('Sadia Rahman', 'sadia@gmail.com',       '016XXXXXXXX', 'Sylhet, Bangladesh'),
('Old Customer', 'oldcustomer@gmail.com', '015XXXXXXXX', 'Khulna, Bangladesh');


-- =====================================================================
-- PART C: SQL DML (Insert / Update / Delete)
-- =====================================================================

-- Q5: Insert a new vendor "SmartTech Ltd." under the Basic plan
INSERT INTO Vendor (business_name, contact_person, email, phone, business_address, plan_id)
VALUES ('SmartTech Ltd.', 'Rahim Khan', 'rahim@smarttech.com', '017XXXXXXXX', 'Dhaka, Bangladesh',
        (SELECT plan_id FROM SubscriptionPlan WHERE plan_name = 'Basic'));

-- Q6 (step 1): Insert the product "Laptop" for SmartTech Ltd.
INSERT INTO Product (vendor_id, product_name, description, price, stock_quantity, status)
VALUES ((SELECT vendor_id FROM Vendor WHERE business_name = 'SmartTech Ltd.'),
        'Laptop', 'High performance laptop', 75000.00, 10, 'active');

-- Q6 (step 2): Link the "Laptop" product to the Electronics category
INSERT INTO ProductCategory (product_id, category_id)
VALUES ((SELECT p.product_id
         FROM Product p
         JOIN Vendor v ON v.vendor_id = p.vendor_id
         WHERE p.product_name = 'Laptop' AND v.business_name = 'SmartTech Ltd.'),
        (SELECT category_id FROM Category WHERE category_name = 'Electronics'));

-- More sample products, categories, orders and payments for the queries below
INSERT INTO Product (vendor_id, product_name, description, price, stock_quantity, status) VALUES
((SELECT vendor_id FROM Vendor WHERE business_name = 'SmartTech Ltd.'), 'Smartphone',  'Android smartphone',  30000.00, 25, 'active'),
((SELECT vendor_id FROM Vendor WHERE business_name = 'SmartTech Ltd.'), 'Headphones',  'Wireless headphones',  3500.00, 60, 'active'),
((SELECT vendor_id FROM Vendor WHERE business_name = 'StyleHub'),       'T-Shirt',     'Cotton t-shirt',        800.00, 100, 'active'),
((SELECT vendor_id FROM Vendor WHERE business_name = 'StyleHub'),       'Sneakers',    'Running sneakers',     4500.00, 40, 'active');

INSERT INTO ProductCategory (product_id, category_id) VALUES
((SELECT product_id FROM Product WHERE product_name = 'Smartphone'), (SELECT category_id FROM Category WHERE category_name = 'Electronics')),
((SELECT product_id FROM Product WHERE product_name = 'Headphones'), (SELECT category_id FROM Category WHERE category_name = 'Electronics')),
((SELECT product_id FROM Product WHERE product_name = 'T-Shirt'),    (SELECT category_id FROM Category WHERE category_name = 'Fashion')),
((SELECT product_id FROM Product WHERE product_name = 'Sneakers'),   (SELECT category_id FROM Category WHERE category_name = 'Fashion'));

-- Orders (order 1 and 2 belong to Karim Uddin, order 3 to Sadia Rahman)
INSERT INTO Orders (customer_id, order_date, total_amount, order_status) VALUES
((SELECT customer_id FROM Customer WHERE name = 'Karim Uddin'),  '2026-10-01', 78500.00, 'delivered'),
((SELECT customer_id FROM Customer WHERE name = 'Karim Uddin'),  '2026-10-05',  3500.00, 'shipped'),
((SELECT customer_id FROM Customer WHERE name = 'Sadia Rahman'), '2026-10-07',  5300.00, 'pending');

INSERT INTO OrderItem (order_id, product_id, quantity, unit_price, subtotal) VALUES
(1, (SELECT product_id FROM Product WHERE product_name = 'Laptop'),     1, 75000.00, 75000.00),
(1, (SELECT product_id FROM Product WHERE product_name = 'Headphones'), 1,  3500.00,  3500.00),
(2, (SELECT product_id FROM Product WHERE product_name = 'Headphones'), 1,  3500.00,  3500.00),
(3, (SELECT product_id FROM Product WHERE product_name = 'T-Shirt'),    1,   800.00,   800.00),
(3, (SELECT product_id FROM Product WHERE product_name = 'Sneakers'),   1,  4500.00,  4500.00);

INSERT INTO Payment (order_id, method, amount, payment_date, payment_status) VALUES
(1, 'Card',             78500.00, '2026-10-01', 'paid'),
(2, 'Bkash',             3500.00, '2026-10-05', 'paid'),
(3, 'Cash on Delivery',  5300.00, '2026-10-07', 'pending');

-- Q7: Update the stock quantity of the "Laptop" product to 15
UPDATE Product
SET stock_quantity = 15
WHERE product_name = 'Laptop';

-- Q8: Delete the customer whose email is "oldcustomer@gmail.com"
DELETE FROM Customer
WHERE email = 'oldcustomer@gmail.com';


-- =====================================================================
-- PART D: SQL Queries (DQL)
-- =====================================================================

-- Q9: Display all vendors along with their subscription plan name and price
SELECT v.vendor_id,
       v.business_name,
       sp.plan_name,
       sp.price
FROM Vendor v
JOIN SubscriptionPlan sp ON sp.plan_id = v.plan_id;

-- Q10: Find all products under the "Electronics" category
--      with their name, price and stock quantity
SELECT p.product_name,
       p.price,
       p.stock_quantity
FROM Product p
JOIN ProductCategory pc ON pc.product_id = p.product_id
JOIN Category c         ON c.category_id = pc.category_id
WHERE c.category_name = 'Electronics';

-- Q11: List all orders placed by customer "Karim Uddin"
SELECT o.order_id,
       o.order_date,
       o.total_amount,
       o.order_status
FROM Orders o
JOIN Customer c ON c.customer_id = o.customer_id
WHERE c.name = 'Karim Uddin';

-- Q12: Show the payment details (method, amount, status) for order_id = 1
SELECT method,
       amount,
       payment_status
FROM Payment
WHERE order_id = 1;

-- Q13: Find the top 5 best-selling products based on total quantity sold
SELECT p.product_id,
       p.product_name,
       SUM(oi.quantity) AS total_quantity_sold
FROM OrderItem oi
JOIN Product p ON p.product_id = oi.product_id
GROUP BY p.product_id, p.product_name
ORDER BY total_quantity_sold DESC
LIMIT 5;
